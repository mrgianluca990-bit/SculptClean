//! CLI for cathar — audio restoration toolbox.

mod banner;

use anyhow::Result;
use cathar::Denoiser;
use clap::{Parser, Subcommand};
use rayon::prelude::*;
use serde::Deserialize;

#[cfg(feature = "tui")]
mod player;
#[cfg(feature = "tui")]
mod termcolor;
#[cfg(feature = "tui")]
mod tui;

#[derive(Debug, Clone, clap::ValueEnum)]
enum EnhanceMethodArg {
    /// Spectral band replication (SBR).
    Replicate,
    /// Log-magnitude extrapolation into the empty high band.
    Interpolate,
    /// Overtone extrapolation (HRAudioWizard HFP family).
    Harmonic,
    /// Nonlinear harmonic generation (DSRE / DSEE-like).
    Dsre,
}

impl From<EnhanceMethodArg> for cathar::EnhanceMethod {
    fn from(m: EnhanceMethodArg) -> Self {
        match m {
            EnhanceMethodArg::Replicate => cathar::EnhanceMethod::Replicate,
            EnhanceMethodArg::Interpolate => cathar::EnhanceMethod::Interpolate,
            EnhanceMethodArg::Harmonic => cathar::EnhanceMethod::Harmonic,
            EnhanceMethodArg::Dsre => cathar::EnhanceMethod::Dsre,
        }
    }
}

#[derive(Debug, Clone, clap::ValueEnum)]
enum DeclickMethodArg {
    /// Autoregressive Janssen interpolation (default, higher quality).
    Ar,
    /// Cubic-Hermite fill (legacy, fast).
    Cubic,
}

#[derive(Debug, Clone, clap::ValueEnum)]
enum DeplosiveMethodArg {
    /// Event-gated low-band expander (default). Undamaged material is untouched.
    Events,
    /// Whole-file STFT band-transient suppression (legacy).
    Transients,
}

impl From<DeplosiveMethodArg> for cathar::DeplosiveMethod {
    fn from(m: DeplosiveMethodArg) -> Self {
        match m {
            DeplosiveMethodArg::Events => cathar::DeplosiveMethod::Events,
            DeplosiveMethodArg::Transients => cathar::DeplosiveMethod::Transients,
        }
    }
}

impl From<DeclickMethodArg> for cathar::DeclickMethod {
    fn from(m: DeclickMethodArg) -> Self {
        match m {
            DeclickMethodArg::Ar => cathar::DeclickMethod::Ar,
            DeclickMethodArg::Cubic => cathar::DeclickMethod::Cubic,
        }
    }
}

#[derive(Debug, Clone, clap::ValueEnum)]
enum DeclipMethodArg {
    /// A-SPADE sparse Gabor reconstruction (default, survey-preferred).
    Spade,
    /// Cubic-Hermite shoulder fill (legacy, fast).
    Cubic,
    /// Social sparsity (PEW neighbourhood shrink + consistency).
    Social,
    /// Constrained OMP on a per-frame DFT dictionary.
    Omp,
    /// Non-negative matrix factorization of the STFT magnitude.
    Nmf,
    /// Deep-unfolded soft-threshold ISTA (LISTA-style, no trained weights).
    Neural,
}

impl From<DeclipMethodArg> for cathar::DeclipMethod {
    fn from(m: DeclipMethodArg) -> Self {
        match m {
            DeclipMethodArg::Spade => cathar::DeclipMethod::Spade,
            DeclipMethodArg::Cubic => cathar::DeclipMethod::Cubic,
            DeclipMethodArg::Social => cathar::DeclipMethod::Social,
            DeclipMethodArg::Omp => cathar::DeclipMethod::Omp,
            DeclipMethodArg::Nmf => cathar::DeclipMethod::Nmf,
            DeclipMethodArg::Neural => cathar::DeclipMethod::Neural,
        }
    }
}

#[derive(Debug, Clone, clap::ValueEnum)]
enum StretchModeArg {
    /// Waveform-similarity overlap-add (robust default, no FFT).
    Wsola,
    /// Phase vocoder (smoother on tonal material).
    Pv,
}

impl From<StretchModeArg> for cathar::StretchMode {
    fn from(m: StretchModeArg) -> Self {
        match m {
            StretchModeArg::Wsola => cathar::StretchMode::Wsola,
            StretchModeArg::Pv => cathar::StretchMode::PhaseVocoder,
        }
    }
}

#[derive(Debug, Clone, clap::ValueEnum)]
enum LagMethodArg {
    /// Time-domain cross-correlation (default).
    Correlation,
    /// GCC-PHAT — better on level-mismatched / mildly reverberant pairs.
    #[value(name = "gcc-phat")]
    GccPhat,
}

impl From<LagMethodArg> for cathar::LagMethod {
    fn from(m: LagMethodArg) -> Self {
        match m {
            LagMethodArg::Correlation => cathar::LagMethod::Correlation,
            LagMethodArg::GccPhat => cathar::LagMethod::GccPhat,
        }
    }
}

#[derive(Debug, Clone, clap::ValueEnum)]
enum EmphasisArg {
    /// FM broadcast, 50 µs (Europe/ITU-R).
    Fm50,
    /// FM broadcast, 75 µs (Americas/Japan).
    Fm75,
    /// CD / IEC 60908 optional pre-emphasis (50/15 µs).
    Cd,
}

#[derive(Debug, Clone, Copy, clap::ValueEnum)]
enum DequantMethodArg {
    /// Local lattice neighbour prediction.
    Lattice,
    /// Iterative first/second-order co-sparse recovery.
    Cosparse,
}

impl From<EmphasisArg> for cathar::Emphasis {
    fn from(m: EmphasisArg) -> Self {
        match m {
            EmphasisArg::Fm50 => cathar::Emphasis::Fm50,
            EmphasisArg::Fm75 => cathar::Emphasis::Fm75,
            EmphasisArg::Cd => cathar::Emphasis::CdIec,
        }
    }
}

#[derive(Debug, Clone, Deserialize)]
struct ChainPreset {
    stages: Vec<ChainStage>,
}

#[derive(Debug, Clone, Deserialize)]
#[serde(tag = "effect", rename_all = "kebab-case")]
enum ChainStage {
    Gain {
        db: f32,
    },
    Denoise {
        #[serde(default = "default_alpha")]
        alpha: f32,
        #[serde(default = "default_beta")]
        beta: f32,
    },
    Dehum {
        #[serde(default = "default_hum_freq")]
        freq: f32,
        #[serde(default = "default_harmonics")]
        harmonics: usize,
    },
    Dewind {
        #[serde(default = "default_wind_cutoff")]
        cutoff: f32,
    },
    Normalize {
        target: f32,
    },
    Echo {
        delay_ms: f32,
        #[serde(default)]
        feedback: f32,
        #[serde(default = "default_mix")]
        mix: f32,
    },
    Reverb {
        #[serde(default = "default_room")]
        room: f32,
        #[serde(default = "default_mix")]
        mix: f32,
    },
    Chorus {
        #[serde(default = "default_chorus_rate")]
        rate: f32,
        #[serde(default = "default_chorus_depth")]
        depth_ms: f32,
        #[serde(default = "default_mix")]
        mix: f32,
    },
    Flanger {
        #[serde(default = "default_flanger_rate")]
        rate: f32,
        #[serde(default = "default_flanger_depth")]
        depth_ms: f32,
        #[serde(default)]
        feedback: f32,
        #[serde(default = "default_mix")]
        mix: f32,
    },
    Phaser {
        #[serde(default = "default_phaser_rate")]
        rate: f32,
        #[serde(default = "default_depth")]
        depth: f32,
        #[serde(default)]
        feedback: f32,
        #[serde(default = "default_mix")]
        mix: f32,
    },
    Tremolo {
        #[serde(default = "default_tremolo_rate")]
        rate: f32,
        #[serde(default = "default_depth")]
        depth: f32,
    },
    Overdrive {
        #[serde(default = "default_drive")]
        drive: f32,
        #[serde(default = "default_mix")]
        mix: f32,
    },
    Compand {
        #[serde(default = "default_threshold")]
        threshold: f32,
        #[serde(default = "default_ratio")]
        ratio: f32,
        #[serde(default = "default_attack")]
        attack: f32,
        #[serde(default = "default_release")]
        release: f32,
        #[serde(default)]
        makeup: f32,
    },
    Contrast {
        #[serde(default = "default_contrast")]
        amount: f32,
    },
}

fn default_alpha() -> f32 {
    3.0
}
fn default_beta() -> f32 {
    0.01
}
fn default_hum_freq() -> f32 {
    60.0
}
fn default_harmonics() -> usize {
    5
}
fn default_wind_cutoff() -> f32 {
    80.0
}
fn default_mix() -> f32 {
    0.5
}
fn default_room() -> f32 {
    0.5
}
fn default_chorus_rate() -> f32 {
    0.35
}
fn default_chorus_depth() -> f32 {
    8.0
}
fn default_flanger_rate() -> f32 {
    0.25
}
fn default_flanger_depth() -> f32 {
    3.0
}
fn default_phaser_rate() -> f32 {
    0.3
}
fn default_depth() -> f32 {
    0.8
}
fn default_tremolo_rate() -> f32 {
    5.0
}
fn default_drive() -> f32 {
    1.0
}
fn default_threshold() -> f32 {
    -20.0
}
fn default_ratio() -> f32 {
    2.0
}
fn default_attack() -> f32 {
    0.01
}
fn default_release() -> f32 {
    0.1
}
fn default_contrast() -> f32 {
    0.5
}

fn parse_chain_file(path: &str) -> Result<ChainPreset> {
    let text = std::fs::read_to_string(path)?;
    if !path.to_ascii_lowercase().ends_with(".toml") {
        return Ok(serde_json::from_str(&text)?);
    }
    let mut stages = Vec::new();
    let mut current = serde_json::Map::new();
    for raw in text.lines() {
        let line = raw.split('#').next().unwrap_or_default().trim();
        if line.is_empty() {
            continue;
        }
        if line == "[[stages]]" {
            if !current.is_empty() {
                stages.push(serde_json::Value::Object(std::mem::take(&mut current)));
            }
            continue;
        }
        let (key, value) =
            line.split_once('=').ok_or_else(|| anyhow::anyhow!("invalid TOML line: {line}"))?;
        let parsed = serde_json::from_str(value.trim()).unwrap_or_else(|_| {
            serde_json::Value::String(value.trim().trim_matches('"').to_owned())
        });
        current.insert(key.trim().to_owned(), parsed);
    }
    if !current.is_empty() {
        stages.push(serde_json::Value::Object(current));
    }
    Ok(serde_json::from_value(serde_json::json!({"stages": stages}))?)
}

fn apply_chain(mut audio: cathar::AudioData, preset: ChainPreset) -> Result<cathar::AudioData> {
    for stage in preset.stages {
        let sr = audio.sample_rate;
        audio = match stage {
            ChainStage::Gain { db } => audio.gain_db(db),
            ChainStage::Denoise { alpha, beta } => {
                cathar::SpectralDenoiser { alpha, beta, ..Default::default() }.denoise(&audio)?
            }
            ChainStage::Dehum { freq, harmonics } => {
                audio.map_channels(|c| cathar::dehum(c, sr, freq, harmonics))
            }
            ChainStage::Dewind { cutoff } => audio.map_channels(|c| cathar::dewind(c, sr, cutoff)),
            ChainStage::Normalize { target } => audio.normalize_r128(target, -1.0),
            ChainStage::Echo { delay_ms, feedback, mix } => {
                audio.map_channels(|c| cathar::echo(c, sr, delay_ms, feedback, mix))
            }
            ChainStage::Reverb { room, mix } => {
                audio.map_channels(|c| cathar::reverb(c, sr, room, mix))
            }
            ChainStage::Chorus { rate, depth_ms, mix } => {
                audio.map_channels(|c| cathar::chorus(c, sr, rate, depth_ms, mix))
            }
            ChainStage::Flanger { rate, depth_ms, feedback, mix } => {
                audio.map_channels(|c| cathar::flanger(c, sr, rate, depth_ms, feedback, mix))
            }
            ChainStage::Phaser { rate, depth, feedback, mix } => {
                audio.map_channels(|c| cathar::phaser(c, sr, rate, depth, feedback, mix))
            }
            ChainStage::Tremolo { rate, depth } => {
                audio.map_channels(|c| cathar::tremolo(c, sr, rate, depth))
            }
            ChainStage::Overdrive { drive, mix } => {
                audio.map_channels(|c| cathar::overdrive(c, drive, mix))
            }
            ChainStage::Compand { threshold, ratio, attack, release, makeup } => audio
                .map_channels(|c| {
                    cathar::compand_dynamic(c, sr, threshold, ratio, attack, release, makeup)
                }),
            ChainStage::Contrast { amount } => audio.map_channels(|c| cathar::contrast(c, amount)),
        };
    }
    Ok(audio)
}

/// Audio restoration toolbox — denoise, de-hum, de-click, de-clip, normalise.
#[derive(Debug, Parser)]
#[command(
    name = "cathar",
    version,
    about = "Restore, enhance & level any recording — in pure Rust",
    long_about = None
)]
struct Cli {
    /// Suppress the startup banner.
    #[arg(long, global = true)]
    no_banner: bool,

    #[command(subcommand)]
    command: Command,
}

#[derive(Debug, Subcommand)]
enum Command {
    /// Denoise audio with spectral subtraction.
    Denoise {
        /// Input file (any format: WAV, MP3, MP4, M4A, MKV, FLAC, OGG)
        input: String,
        /// Output WAV file
        #[arg(short, long, default_value = "clean.wav")]
        out: String,
        /// Aggressiveness (1.0 = gentle, 6.0 = aggressive)
        #[arg(short, long, default_value_t = 3.0)]
        alpha: f32,
        /// Spectral floor (0.0–0.1, higher = less artifacts)
        #[arg(short = 'b', long, default_value_t = 0.01)]
        beta: f32,
        /// Pre-computed noise print (from `noiseprint` command)
        #[arg(long)]
        noiseprint: Option<String>,
        /// Use Wiener filter instead of spectral subtraction
        #[arg(long)]
        wiener: bool,
        /// Phase-coherent stereo: one shared gain mask keeps the stereo image stable
        #[arg(long)]
        coherent: bool,
    },
    /// Learn a noise profile from a silence/noise-only recording.
    Noiseprint {
        /// Input file containing only noise/silence
        input: String,
        /// Output noise print file (JSON)
        #[arg(short, long, default_value = "noise.np.json")]
        out: String,
    },
    /// Remove mains hum (50/60 Hz + harmonics).
    Dehum {
        /// Input file
        input: String,
        /// Output WAV file
        #[arg(short, long, default_value = "dehummed.wav")]
        out: String,
        /// Base frequency (50 or 60 Hz). `0` auto-detects from the recording.
        #[arg(short = 'f', long, default_value_t = 60.0)]
        freq: f32,
        /// Number of harmonics to notch
        #[arg(short = 'n', long, default_value_t = 5)]
        harmonics: usize,
        /// Track a drifting fundamental + per-harmonic amplitude (adaptive).
        /// Also auto-picks 50 vs 60 when the other series is clearly stronger,
        /// and skips harmonics that do not stand out — so no-hum files pass
        /// through unchanged.
        #[arg(long)]
        adaptive: bool,
    },
    /// Detect and remove impulse clicks (vinyl rips, bad edits).
    Declick {
        /// Input file
        input: String,
        /// Output WAV file
        #[arg(short, long, default_value = "declicked.wav")]
        out: String,
        /// Detection threshold (higher = less sensitive)
        #[arg(short, long, default_value_t = 10.0)]
        threshold: f32,
        /// Reconstruction method: `ar` (Janssen, default) or `cubic` (legacy)
        #[arg(long, value_enum, default_value_t = DeclickMethodArg::Ar)]
        method: DeclickMethodArg,
    },
    /// Suppress dense low-level surface crackle (vinyl), distinct from de-click.
    Decrackle {
        /// Input file
        input: String,
        /// Output WAV file
        #[arg(short, long, default_value = "decrackled.wav")]
        out: String,
        /// Sensitivity 1–10 (higher removes more)
        #[arg(short, long, default_value_t = 5.0)]
        sensitivity: f32,
    },
    /// Reconstruct clipped peaks (overdriven recordings).
    Declip {
        /// Input file
        input: String,
        /// Output WAV file
        #[arg(short, long, default_value = "declipped.wav")]
        out: String,
        /// Clipping threshold (0.0–1.0)
        #[arg(short, long, default_value_t = 0.95)]
        threshold: f32,
        /// Reconstruction: spade|cubic|social|omp|nmf|neural (default spade)
        #[arg(long, value_enum, default_value_t = DeclipMethodArg::Spade)]
        method: DeclipMethodArg,
    },
    /// Remove room echo and reverb from recordings.
    Dereverb {
        /// Input file
        input: String,
        /// Output WAV file
        #[arg(short, long, default_value = "dereverbed.wav")]
        out: String,
        /// Strength (1.0 = gentle, 5.0 = aggressive)
        #[arg(short, long, default_value_t = 2.0)]
        strength: f32,
        /// Use WPE (Weighted Prediction Error) linear-prediction dereverb
        #[arg(long)]
        wpe: bool,
        /// WPE prediction taps (only with --wpe)
        #[arg(long, default_value_t = 15)]
        taps: usize,
        /// WPE prediction delay in frames (only with --wpe)
        #[arg(long, default_value_t = 3)]
        delay: usize,
    },
    /// Isolate speech from background noise.
    Voiceisolate {
        /// Input file
        input: String,
        /// Output WAV file
        #[arg(short, long, default_value = "isolated.wav")]
        out: String,
        /// Optional noise print for cleaner separation
        #[arg(long)]
        noiseprint: Option<String>,
    },
    /// Reduce harsh sibilance (s, sh, ch sounds).
    Deesser {
        /// Input file
        input: String,
        /// Output WAV file
        #[arg(short, long, default_value = "deessed.wav")]
        out: String,
        /// Crossover frequency in Hz
        #[arg(short, long, default_value_t = 4000.0)]
        freq: f32,
        /// Threshold in dB (single-band: vs HF/broadband ratio; multiband: dB above each band's running average — try 6)
        #[arg(short, long, default_value_t = -24.0)]
        threshold: f32,
        /// Split the sibilant region into N adaptive sub-bands (1 = classic single-band)
        #[arg(long, default_value_t = 1)]
        bands: usize,
    },
    /// Remove low-frequency wind rumble (high-pass).
    Dewind {
        /// Input file
        input: String,
        /// Output WAV file
        #[arg(short, long, default_value = "dewinded.wav")]
        out: String,
        /// High-pass cutoff in Hz
        #[arg(short, long, default_value_t = 80.0)]
        cutoff: f32,
    },
    /// Tame plosive pops ("p"/"b" low-frequency bursts).
    Deplosive {
        /// Input file
        input: String,
        /// Output WAV file
        #[arg(short, long, default_value = "deplosived.wav")]
        out: String,
        /// Aggressiveness 1–10 (event threshold; 4 ≈ 12 dB of low-band excess)
        #[arg(short, long, default_value_t = 4.0)]
        strength: f32,
        /// `events` (default, gated) or `transients` (legacy whole-file)
        #[arg(long, value_enum, default_value_t = DeplosiveMethodArg::Events)]
        method: DeplosiveMethodArg,
    },
    /// Suppress lavalier / clothing rustle (mid-band transient bursts).
    Derustle {
        /// Input file
        input: String,
        /// Output WAV file
        #[arg(short, long, default_value = "derustled.wav")]
        out: String,
        /// Aggressiveness 1–10
        #[arg(short, long, default_value_t = 4.0)]
        strength: f32,
    },
    /// Attenuate breath sounds between speech segments.
    Breath {
        /// Input file
        input: String,
        /// Output WAV file
        #[arg(short, long, default_value = "breathless.wav")]
        out: String,
    },
    /// Split into harmonic (tonal) and percussive (transient) layers (HPSS).
    Hpss {
        /// Input file
        input: String,
        /// Harmonic output WAV file
        #[arg(long, default_value = "harmonic.wav")]
        harmonic: String,
        /// Percussive output WAV file
        #[arg(long, default_value = "percussive.wav")]
        percussive: String,
        /// Median-filter length (odd, ≥ 3)
        #[arg(short, long, default_value_t = 17)]
        kernel: usize,
    },
    /// Tonal purify via sinusoidal modeling (SMS): keep tracked partials, drop
    /// the stochastic residual.
    Sms {
        /// Input file
        input: String,
        /// Output WAV file
        #[arg(short, long, default_value = "sms.wav")]
        out: String,
    },
    /// Correct wow & flutter (pitch-drift) from tape/vinyl captures.
    Dewow {
        /// Input file
        input: String,
        /// Output WAV file
        #[arg(short, long, default_value = "dewowed.wav")]
        out: String,
    },
    /// Correct stereo azimuth skew (align R to L by cross-correlation).
    Azimuth {
        /// Input stereo file
        input: String,
        /// Output WAV file
        #[arg(short, long, default_value = "azimuth.wav")]
        out: String,
        /// Max correction search (ms)
        #[arg(long, default_value_t = 5.0)]
        max_ms: f32,
        /// Lag estimator: `correlation` (default) or `gcc-phat`
        #[arg(long, default_value = "correlation")]
        method: LagMethodArg,
    },
    /// Time-align a recording to a reference track (multi-mic).
    Align {
        /// Input file to align
        input: String,
        /// Reference file to align against
        #[arg(long)]
        reference: String,
        /// Output WAV file
        #[arg(short, long, default_value = "aligned.wav")]
        out: String,
        /// Max alignment search (ms)
        #[arg(long, default_value_t = 50.0)]
        max_ms: f32,
        /// Lag estimator: `correlation` (default) or `gcc-phat`
        #[arg(long, default_value = "correlation")]
        method: LagMethodArg,
    },
    /// Mid-side / stereo toolkit: width, mono-maker, M/S encode, mono upmix.
    Stereo {
        /// Input file
        input: String,
        /// Output WAV file
        #[arg(short, long, default_value = "stereo.wav")]
        out: String,
        /// Scale stereo width via mid/side (`0` = mono, `1` = original, `>1` wider)
        #[arg(long)]
        width: Option<f32>,
        /// Sum to mono below this frequency (Hz); highs stay stereo
        #[arg(long)]
        mono_below: Option<f32>,
        /// Encode L/R → M/S (ch0=mid, ch1=side)
        #[arg(long)]
        ms: bool,
        /// Decode M/S → L/R (input ch0=mid, ch1=side)
        #[arg(long)]
        from_ms: bool,
        /// Mono → pseudo-stereo (Haas delay on right)
        #[arg(long)]
        upmix: bool,
        /// Optional Haas inter-channel delay in ms (positive delays right)
        #[arg(long)]
        haas_ms: Option<f32>,
    },
    /// Reconstruct dropouts/mutes by AR interpolation (audio inpainting).
    Inpaint {
        /// Input file
        input: String,
        /// Output WAV file
        #[arg(short, long, default_value = "inpainted.wav")]
        out: String,
        /// Gap start (ms). With `--len-ms`, inpaints this explicit span.
        #[arg(long)]
        start_ms: Option<f32>,
        /// Gap length (ms). Requires `--start-ms`.
        #[arg(long)]
        len_ms: Option<f32>,
        /// Janssen refinement passes
        #[arg(long, default_value_t = 3)]
        iterations: u32,
        /// Auto mode: only fill detected mutes up to this length (ms)
        #[arg(long, default_value_t = 50.0)]
        max_gap_ms: f32,
    },
    /// Apply RIAA playback de-emphasis to a digitized vinyl recording.
    Riaa {
        /// Input file
        input: String,
        /// Output WAV file
        #[arg(short, long, default_value = "riaa.wav")]
        out: String,
        /// Elliptical mono crossover (Hz); sums lows to mono below this frequency
        #[arg(long)]
        elliptical: Option<f32>,
    },
    /// Apply analog playback de-emphasis (FM 50/75 µs or CD/IEC).
    Deemphasis {
        /// Input file
        input: String,
        /// Output WAV file
        #[arg(short, long, default_value = "deemphasized.wav")]
        out: String,
        /// De-emphasis curve
        #[arg(long, default_value = "fm50")]
        curve: EmphasisArg,
    },
    /// Reduce quantization grain from low-bit-depth sources.
    Dequantize {
        /// Input file
        input: String,
        /// Output WAV file
        #[arg(short, long, default_value = "dequantized.wav")]
        out: String,
        /// Assumed source bit depth (4–24)
        #[arg(short, long, default_value_t = 16)]
        bits: u32,
        /// Correction strength 0–1
        #[arg(short, long, default_value_t = 0.7)]
        strength: f32,
        /// Recovery method.
        #[arg(long, value_enum, default_value = "lattice")]
        method: DequantMethodArg,
        /// Co-sparse iterations (used with `--method cosparse`).
        #[arg(long, default_value_t = 4)]
        iterations: u32,
    },
    /// Restore high frequencies lost to compression or low sample rates.
    Enhance {
        /// Input file
        input: String,
        /// Output WAV file
        #[arg(short, long, default_value = "enhanced.wav")]
        out: String,
        /// Target sample rate (Hz)
        #[arg(short, long, default_value_t = 48000)]
        rate: u32,
        /// Upsampling strategy: replicate, interpolate, harmonic, or dsre
        #[arg(long, default_value = "replicate")]
        method: EnhanceMethodArg,
    },
    /// Repair isolated transient spectral artifacts (whistles, bursts, glitches).
    Repair {
        /// Input file
        input: String,
        /// Output WAV file
        #[arg(short, long, default_value = "repaired.wav")]
        out: String,
        /// Aggressiveness 1–10 (higher removes more)
        #[arg(short, long, default_value_t = 4.0)]
        strength: f32,
    },
    /// Resample to a different sample rate (anti-aliased, any ratio).
    Resample {
        /// Input file
        input: String,
        /// Output WAV file
        #[arg(short, long, default_value = "resampled.wav")]
        out: String,
        /// Target sample rate (Hz)
        #[arg(short, long, default_value_t = 48000)]
        rate: u32,
    },
    /// Change tempo (duration) without changing pitch.
    Tempo {
        /// Input file
        input: String,
        /// Output WAV file
        #[arg(short, long, default_value = "tempo.wav")]
        out: String,
        /// Speed factor: >1 faster/shorter, <1 slower/longer
        #[arg(short, long, default_value_t = 1.5)]
        factor: f32,
        /// Stretch engine
        #[arg(long, default_value = "wsola")]
        mode: StretchModeArg,
    },
    /// Shift pitch (semitones) without changing duration.
    Pitch {
        /// Input file
        input: String,
        /// Output WAV file
        #[arg(short, long, default_value = "pitched.wav")]
        out: String,
        /// Semitones to shift (negative = down)
        #[arg(short, long, default_value_t = 2.0, allow_hyphen_values = true)]
        semitones: f32,
        /// Stretch engine
        #[arg(long, default_value = "wsola")]
        mode: StretchModeArg,
    },
    /// Change speed (resample): alters both pitch and duration, like tape.
    Speed {
        /// Input file
        input: String,
        /// Output WAV file
        #[arg(short, long, default_value = "speed.wav")]
        out: String,
        /// Speed factor: >1 faster/higher, <1 slower/lower
        #[arg(short, long, default_value_t = 1.5)]
        factor: f32,
    },
    /// Normalize loudness or peak level.
    Normalize {
        /// Input file
        input: String,
        /// Output WAV file
        #[arg(short, long, default_value = "normalized.wav")]
        out: String,
        /// Target level in LUFS/dBFS (-23 = broadcast, -16 = podcast, -14 = streaming)
        #[arg(short, long, default_value_t = -16.0, allow_hyphen_values = true)]
        target: f32,
        /// Use peak normalization instead of loudness
        #[arg(long)]
        peak: bool,
        /// True-peak ceiling in dBTP for loudness mode (gain is held back to respect it)
        #[arg(long, default_value_t = -1.0, allow_hyphen_values = true)]
        true_peak: f32,
    },
    /// Generate a synthetic waveform for testing.
    Wave {
        #[arg(short, long, default_value = "test.wav")]
        out: String,
        #[arg(short, long, default_value = "44100")]
        sample_rate: u32,
        #[arg(short, long, default_value_t = 440.0)]
        freq: f32,
        #[arg(short, long, default_value_t = 3.0)]
        duration: f32,
        #[arg(short, long, default_value_t = 0.1)]
        noise: f32,
    },
    /// Tape / VHS restoration chain (gated stages).
    Vhs {
        /// Input file
        input: String,
        /// Output WAV file
        #[arg(short, long, default_value = "vhs.wav")]
        out: String,
        /// Denoise aggressiveness (1 = gentle, 6 = aggressive)
        #[arg(short, long, default_value_t = 2.0)]
        alpha: f32,
        /// Spectral floor
        #[arg(short = 'b', long, default_value_t = 0.01)]
        beta: f32,
        /// Rumble high-pass cutoff in Hz
        #[arg(long, default_value_t = 80.0)]
        cutoff: f32,
        /// Multiband de-ess threshold (dB above each band's running average; not the single-band -24)
        #[arg(long, default_value_t = 6.0, allow_hyphen_values = true)]
        deess_threshold: f32,
        /// Also normalise to this LUFS level
        #[arg(long, allow_hyphen_values = true)]
        normalize: Option<f32>,
    },
    /// Batch process all audio files in a directory.
    Batch {
        /// Input directory
        #[arg(short, long, default_value = ".")]
        indir: String,
        /// Output directory
        #[arg(short, long, default_value = "clean")]
        outdir: String,
        /// Aggressiveness
        #[arg(short, long, default_value_t = 3.0)]
        alpha: f32,
        /// Spectral floor
        #[arg(short = 'b', long, default_value_t = 0.01)]
        beta: f32,
        /// Also de-hum (specify base frequency, e.g. 60)
        #[arg(long)]
        dehum: Option<f32>,
        /// Also normalize to this LUFS level
        #[arg(long)]
        normalize: Option<f32>,
        /// Optional JSON chain preset to apply instead of the built-in denoise chain.
        #[arg(long)]
        preset: Option<String>,
        /// Extensions to process (comma-separated)
        #[arg(long, default_value = "wav,mp3,mp4,m4a,mkv,flac,ogg,aac")]
        exts: String,
    },
    /// View a spectrogram in the terminal (interactive heatmap).
    #[cfg(feature = "tui")]
    View {
        /// Input file (any supported format)
        input: String,
        /// FFT size (frequency resolution = sample_rate / fft)
        #[arg(long, default_value_t = 2048)]
        fft: usize,
        /// Hop between frames in samples (smaller = more time detail)
        #[arg(long, default_value_t = 512)]
        hop: usize,
    },
    /// Trim audio to a time range.
    Trim {
        /// Input file
        input: String,
        /// Output file
        #[arg(short, long, default_value = "trimmed.wav")]
        out: String,
        /// Start time in seconds
        #[arg(short, long, default_value_t = 0.0)]
        start: f32,
        /// Duration in seconds
        #[arg(short, long)]
        duration: f32,
    },
    /// Pad audio with silence at start and/or end.
    Pad {
        /// Input file
        input: String,
        /// Output file
        #[arg(short, long, default_value = "padded.wav")]
        out: String,
        /// Seconds of silence to prepend
        #[arg(long, default_value_t = 0.0)]
        pre: f32,
        /// Seconds of silence to append
        #[arg(long, default_value_t = 0.0)]
        post: f32,
    },
    /// Apply a linear fade-in and/or fade-out.
    Fade {
        /// Input file
        input: String,
        /// Output file
        #[arg(short, long, default_value = "faded.wav")]
        out: String,
        /// Fade-in duration in seconds
        #[arg(long, default_value_t = 0.05)]
        fade_in: f32,
        /// Fade-out duration in seconds
        #[arg(long, default_value_t = 0.1)]
        fade_out: f32,
    },
    /// Strip silence from the start and end of audio.
    Silence {
        /// Input file
        input: String,
        /// Output file
        #[arg(short, long, default_value = "silenced.wav")]
        out: String,
        /// Amplitude threshold below which is considered silence (0.0-1.0)
        #[arg(long, default_value_t = 0.01)]
        threshold: f32,
        /// Minimum silent duration in seconds before trimming
        #[arg(long, default_value_t = 0.1)]
        min_duration: f32,
    },
    /// Apply gain in dB.
    Gain {
        /// Input file
        input: String,
        /// Output file
        #[arg(short, long, default_value = "gained.wav")]
        out: String,
        /// Gain in dB (positive = boost, negative = cut)
        #[arg(long, default_value_t = 0.0, allow_hyphen_values = true)]
        db: f32,
    },
    /// Remix channels (stereo → mono, swap L/R, custom mapping).
    Remix {
        /// Input file
        input: String,
        /// Output file
        #[arg(short, long, default_value = "remixed.wav")]
        out: String,
        /// How to remix: 'mono', 'swap', or comma-separated channel indices
        #[arg(long, default_value = "mono")]
        layout: String,
    },
    /// Select a subset of channels.
    Channels {
        /// Input file
        input: String,
        /// Output file
        #[arg(short, long, default_value = "channeled.wav")]
        out: String,
        /// Comma-separated 0-based channel indices (e.g. "0" for left, "1" for right)
        #[arg(long, default_value = "0")]
        indices: String,
    },
    /// Reverse audio in time.
    Reverse {
        /// Input file
        input: String,
        /// Output file
        #[arg(short, long, default_value = "reversed.wav")]
        out: String,
    },
    /// Apply a low-pass filter (remove high frequencies).
    Lowpass {
        input: String,
        #[arg(short, long, default_value = "lowpassed.wav")]
        out: String,
        /// Cutoff frequency in Hz
        #[arg(short, long)]
        freq: f32,
    },
    /// Apply a high-pass filter (remove low frequencies).
    Highpass {
        input: String,
        #[arg(short, long, default_value = "highpassed.wav")]
        out: String,
        /// Cutoff frequency in Hz
        #[arg(short, long)]
        freq: f32,
    },
    /// Apply a band-pass filter.
    Bandpass {
        input: String,
        #[arg(short, long, default_value = "bandpassed.wav")]
        out: String,
        /// Center frequency in Hz
        #[arg(short, long)]
        freq: f32,
        /// Q factor (bandwidth = freq / Q)
        #[arg(long, default_value_t = 1.0)]
        q: f32,
    },
    /// Apply a peaking (bell) EQ filter.
    Equalizer {
        input: String,
        #[arg(short, long, default_value = "eqd.wav")]
        out: String,
        /// Center frequency in Hz
        #[arg(short, long)]
        freq: f32,
        /// Q factor
        #[arg(long, default_value_t = 1.0)]
        q: f32,
        /// Gain in dB (positive = boost, negative = cut)
        #[arg(short, long, allow_hyphen_values = true)]
        gain: f32,
    },
    /// Apply a low-shelf filter (boost/cut bass).
    Bass {
        input: String,
        #[arg(short, long, default_value = "bassed.wav")]
        out: String,
        /// Cutoff frequency in Hz
        #[arg(short, long)]
        freq: f32,
        /// Gain in dB
        #[arg(short, long, allow_hyphen_values = true, default_value_t = 3.0)]
        gain: f32,
    },
    /// Apply a high-shelf filter (boost/cut treble).
    Treble {
        input: String,
        #[arg(short, long, default_value = "trebled.wav")]
        out: String,
        /// Cutoff frequency in Hz
        #[arg(short, long)]
        freq: f32,
        /// Gain in dB
        #[arg(short, long, allow_hyphen_values = true, default_value_t = 3.0)]
        gain: f32,
    },
    /// Apply a dynamic range compressor.
    Compress {
        input: String,
        #[arg(short, long, default_value = "compressed.wav")]
        out: String,
        /// Threshold in dBFS (e.g. -20)
        #[arg(short, long, default_value_t = -20.0, allow_hyphen_values = true)]
        threshold: f32,
        /// Compression ratio (e.g. 2 for 2:1)
        #[arg(long, default_value_t = 2.0)]
        ratio: f32,
        /// Attack time in seconds
        #[arg(long, default_value_t = 0.01)]
        attack: f32,
        /// Release time in seconds
        #[arg(long, default_value_t = 0.1)]
        release: f32,
    },
    /// Apply a brickwall limiter.
    Limit {
        input: String,
        #[arg(short, long, default_value = "limited.wav")]
        out: String,
        /// Ceiling in dBFS
        #[arg(short, long, default_value_t = -1.0, allow_hyphen_values = true)]
        ceiling: f32,
    },
    /// Apply a noise gate.
    Gate {
        input: String,
        #[arg(short, long, default_value = "gated.wav")]
        out: String,
        /// Threshold in dBFS (e.g. -40)
        #[arg(short, long, default_value_t = -40.0, allow_hyphen_values = true)]
        threshold: f32,
        /// Attack time in seconds
        #[arg(long, default_value_t = 0.001)]
        attack: f32,
        /// Release time in seconds
        #[arg(long, default_value_t = 0.1)]
        release: f32,
    },
    /// Add a delayed echo.
    Echo {
        input: String,
        #[arg(short, long, default_value = "echo.wav")]
        out: String,
        #[arg(long, default_value_t = 250.0)]
        delay_ms: f32,
        #[arg(long, default_value_t = 0.35)]
        feedback: f32,
        #[arg(long, default_value_t = 0.5)]
        mix: f32,
    },
    /// Add a synthetic room reverb.
    Reverb {
        input: String,
        #[arg(short, long, default_value = "reverb.wav")]
        out: String,
        #[arg(long, default_value_t = 0.5)]
        room: f32,
        #[arg(long, default_value_t = 0.3)]
        mix: f32,
    },
    /// Apply a chorus effect.
    Chorus {
        input: String,
        #[arg(short, long, default_value = "chorus.wav")]
        out: String,
        #[arg(long, default_value_t = 0.35)]
        rate: f32,
        #[arg(long, default_value_t = 8.0)]
        depth_ms: f32,
        #[arg(long, default_value_t = 0.5)]
        mix: f32,
    },
    /// Apply a flanger effect.
    Flanger {
        input: String,
        #[arg(short, long, default_value = "flanger.wav")]
        out: String,
        #[arg(long, default_value_t = 0.25)]
        rate: f32,
        #[arg(long, default_value_t = 3.0)]
        depth_ms: f32,
        #[arg(long, default_value_t = 0.5)]
        feedback: f32,
        #[arg(long, default_value_t = 0.5)]
        mix: f32,
    },
    /// Apply a phase-shifting modulation effect.
    Phaser {
        input: String,
        #[arg(short, long, default_value = "phaser.wav")]
        out: String,
        #[arg(long, default_value_t = 0.3)]
        rate: f32,
        #[arg(long, default_value_t = 0.8)]
        depth: f32,
        #[arg(long, default_value_t = 0.3)]
        feedback: f32,
        #[arg(long, default_value_t = 0.5)]
        mix: f32,
    },
    /// Apply amplitude modulation.
    Tremolo {
        input: String,
        #[arg(short, long, default_value = "tremolo.wav")]
        out: String,
        #[arg(long, default_value_t = 5.0)]
        rate: f32,
        #[arg(long, default_value_t = 0.5)]
        depth: f32,
    },
    /// Apply tanh soft-clipping overdrive.
    Overdrive {
        input: String,
        #[arg(short, long, default_value = "overdrive.wav")]
        out: String,
        #[arg(long, default_value_t = 1.0)]
        drive: f32,
        #[arg(long, default_value_t = 1.0)]
        mix: f32,
    },
    /// Apply a time-varying broadband compressor curve.
    Compand {
        input: String,
        #[arg(short, long, default_value = "companded.wav")]
        out: String,
        #[arg(long, default_value_t = -20.0, allow_hyphen_values = true)]
        threshold: f32,
        #[arg(long, default_value_t = 2.0)]
        ratio: f32,
        #[arg(long, default_value_t = 0.01)]
        attack: f32,
        #[arg(long, default_value_t = 0.1)]
        release: f32,
        #[arg(long, default_value_t = 0.0, allow_hyphen_values = true)]
        makeup: f32,
    },
    /// Increase or decrease waveform contrast.
    Contrast {
        input: String,
        #[arg(short, long, default_value = "contrasted.wav")]
        out: String,
        #[arg(long, default_value_t = 0.5, allow_hyphen_values = true)]
        amount: f32,
    },
    /// Apply Bark-scale masking-aware denoising.
    PsychoDenoise {
        input: String,
        #[arg(short, long, default_value = "psycho-clean.wav")]
        out: String,
        #[arg(short, long, default_value_t = 3.0)]
        alpha: f32,
        #[arg(short = 'b', long, default_value_t = 0.02)]
        beta: f32,
    },
    /// Match a recording's long-term spectrum to a clean reference.
    Rebalance {
        input: String,
        #[arg(long)]
        reference: String,
        #[arg(short, long, default_value = "rebalanced.wav")]
        out: String,
        #[arg(long, default_value_t = 1.0)]
        strength: f32,
    },
    /// Correct a recording using a measured impulse response.
    Deconvolve {
        /// Recorded signal to correct.
        input: String,
        /// Measured impulse-response audio file.
        #[arg(long)]
        impulse: String,
        #[arg(short, long, default_value = "deconvolved.wav")]
        out: String,
        /// Wiener regularization as a fraction of peak IR power.
        #[arg(long, default_value_t = 0.0001)]
        regularization: f32,
    },
    /// Run a declarative JSON processing chain.
    Chain {
        /// Input audio file.
        input: String,
        /// JSON preset containing a `stages` array.
        #[arg(long)]
        preset: String,
        #[arg(short, long, default_value = "chained.wav")]
        out: String,
    },
    /// Apply TPDF dither (for bit-depth reduction).
    Dither {
        /// Input file
        input: String,
        /// Output file
        #[arg(short, long, default_value = "dithered.wav")]
        out: String,
        /// Target bit depth (e.g. 16)
        #[arg(long, default_value_t = 16)]
        bits: u32,
    },
    /// Print audio statistics (peak, RMS, LUFS, true-peak, crest, noise floor, clip runs).
    Stats {
        /// Input file
        input: String,
    },
    /// Convert between audio formats (WAV, FLAC, AIFF, MP3, …) without processing.
    Convert {
        /// Input file (any format: WAV, MP3, MP4, M4A, MKV, FLAC, OGG, AIFF)
        input: String,
        /// Output file (format chosen by extension: .wav, .flac, .aiff)
        #[arg(short, long)]
        out: String,
    },
    /// Neural spectral-gain denoise (candle GRU). Requires `--features ml`.
    #[cfg(feature = "ml")]
    MlDenoise {
        /// Input file (any format: WAV, MP3, MP4, M4A, MKV, FLAC, OGG)
        input: String,
        /// Output WAV file
        #[arg(short, long, default_value = "clean.wav")]
        out: String,
        /// Path to a custom `.safetensors` checkpoint. Omit to use the bundled
        /// pretrained model (synthetic tones; retrain on DNS-Challenge for speech).
        #[arg(long)]
        weights: Option<String>,
        /// Use the deterministic passthrough model instead of the pretrained one.
        #[arg(long, conflicts_with = "weights")]
        passthrough: bool,
    },
    /// Play a file with a live spectrum-analyzer visualizer (Winamp-style).
    #[cfg(feature = "tui")]
    Play {
        /// Input file (any supported format)
        input: String,
        /// FFT size for the analyzer (larger = finer frequency bands)
        #[arg(long, default_value_t = 2048)]
        fft: usize,
    },
}

fn main() -> Result<()> {
    if !std::env::args().any(|a| a == "--no-banner") {
        banner::print();
    }

    tracing_subscriber::fmt()
        .with_env_filter(tracing_subscriber::EnvFilter::from_default_env())
        .init();

    let cli = Cli::parse();

    match cli.command {
        Command::Denoise { input, out, alpha, beta, noiseprint, wiener, coherent } => {
            let audio = cathar::AudioData::from_file(&input)?;
            let orig_power = power(&audio.channels[0]);

            eprintln!(
                "{}  {} Hz  {} ch  {:.1}s",
                input,
                audio.sample_rate,
                audio.channels.len(),
                audio.channels[0].len() as f32 / audio.sample_rate as f32
            );

            let clean = if let Some(np_path) = noiseprint {
                let np_json = std::fs::read_to_string(&np_path)?;
                let np: Vec<f32> = serde_json::from_str(&np_json)?;
                let noise_print = cathar::NoisePrint { fft_size: 2048, spectrum: np };
                let denoiser = cathar::SpectralDenoiser::with_noise_print(noise_print, alpha, beta);
                if coherent {
                    denoiser.denoise_coherent(&audio)?
                } else {
                    denoiser.denoise(&audio)?
                }
            } else if wiener {
                let np = cathar::learn_noise_print(&audio)?;
                let output = cathar::wiener_denoise(&audio.channels[0], &np, alpha)?;
                cathar::AudioData { sample_rate: audio.sample_rate, channels: vec![output] }
            } else {
                let denoiser = cathar::SpectralDenoiser { alpha, beta, ..Default::default() };
                if coherent {
                    denoiser.denoise_coherent(&audio)?
                } else {
                    denoiser.denoise(&audio)?
                }
            };

            clean.to_file(&out)?;
            let clean_power = power(&clean.channels[0]);
            if let (Some(o), Some(c)) = (orig_power, clean_power) {
                if o > 0.0 {
                    let db = -10.0 * (c / o).log10();
                    eprintln!("reduction  {:.1}%  ({db:.1} dB)", (1.0 - c / o) * 100.0);
                }
            }
            eprintln!("wrote  {out}");
        }

        Command::Noiseprint { input, out } => {
            let audio = cathar::AudioData::from_file(&input)?;
            let np = cathar::learn_noise_print(&audio)?;
            let json = serde_json::to_string(&np.spectrum)?;
            std::fs::write(&out, json)?;
            eprintln!(
                "{}  {} Hz  {:.1}s  →  {} ({} bins, FFT={})",
                input,
                audio.sample_rate,
                audio.channels[0].len() as f32 / audio.sample_rate as f32,
                out,
                np.spectrum.len(),
                np.fft_size
            );
        }

        Command::Dehum { input, out, freq, harmonics, adaptive } => {
            let audio = cathar::AudioData::from_file(&input)?;
            let sr = audio.sample_rate;
            let mix = mixdown(&audio);
            let freq =
                if freq <= 0.0 { cathar::detect_mains_hz(&mix, sr).unwrap_or(60.0) } else { freq };
            let cleaned = if adaptive {
                audio.map_channels(|c| cathar::dehum_adaptive(c, sr, freq, harmonics))
            } else {
                audio.map_channels(|c| cathar::dehum(c, sr, freq, harmonics))
            };
            cleaned.to_file(&out)?;
            let mode = if adaptive { " (adaptive)" } else { "" };
            eprintln!("de-hummed{mode}  {freq} Hz + {harmonics} harmonics  →  {out}");
        }

        Command::Declick { input, out, threshold, method } => {
            let audio = cathar::AudioData::from_file(&input)?;
            let method: cathar::DeclickMethod = method.into();
            let cleaned =
                audio.map_channels(|c| cathar::declick_with_method(c, threshold, 64, method));
            cleaned.to_file(&out)?;
            let m = match method {
                cathar::DeclickMethod::Ar => "ar",
                cathar::DeclickMethod::Cubic => "cubic",
            };
            eprintln!("de-clicked  threshold={threshold}  method={m}  →  {out}");
        }

        Command::Declip { input, out, threshold, method } => {
            let audio = cathar::AudioData::from_file(&input)?;
            let method: cathar::DeclipMethod = method.into();
            let cleaned = audio.map_channels(|c| cathar::declip_with_method(c, threshold, method));
            cleaned.to_file(&out)?;
            let m = match method {
                cathar::DeclipMethod::Spade => "spade",
                cathar::DeclipMethod::Cubic => "cubic",
                cathar::DeclipMethod::Social => "social",
                cathar::DeclipMethod::Omp => "omp",
                cathar::DeclipMethod::Nmf => "nmf",
                cathar::DeclipMethod::Neural => "neural",
            };
            eprintln!("de-clipped  threshold={threshold}  method={m}  →  {out}");
        }
        Command::Decrackle { input, out, sensitivity } => {
            let audio = cathar::AudioData::from_file(&input)?;
            let sr = audio.sample_rate;
            let cleaned = audio.map_channels(|c| cathar::decrackle(c, sr, sensitivity));
            cleaned.to_file(&out)?;
            eprintln!("de-crackled  sensitivity={sensitivity}  →  {out}");
        }
        Command::Dereverb { input, out, strength, wpe, taps, delay } => {
            let audio = cathar::AudioData::from_file(&input)?;
            let sr = audio.sample_rate;
            let cleaned = if wpe {
                audio.map_channels(|c| cathar::wpe(c, sr, taps, delay, 3))
            } else {
                audio.map_channels(|c| cathar::dereverb(c, sr, strength))
            };
            cleaned.to_file(&out)?;
            if wpe {
                eprintln!("de-reverbed (WPE, {taps} taps)  →  {out}");
            } else {
                eprintln!("de-reverbed  strength={strength}  →  {out}");
            }
        }
        Command::Voiceisolate { input, out, noiseprint } => {
            let audio = cathar::AudioData::from_file(&input)?;
            let np = if let Some(ref path) = noiseprint {
                let json = std::fs::read_to_string(path)?;
                let spectrum: Vec<f32> = serde_json::from_str(&json)?;
                Some(cathar::NoisePrint { fft_size: 2048, spectrum })
            } else {
                None
            };
            let cleaned =
                audio.map_channels(|c| cathar::voice_isolate(c, audio.sample_rate, np.as_ref()));
            cleaned.to_file(&out)?;
            eprintln!("voice-isolated  →  {out}");
        }
        Command::Deesser { input, out, freq, threshold, bands } => {
            let audio = cathar::AudioData::from_file(&input)?;
            if bands > 1 && threshold <= 0.0 {
                eprintln!(
                    "warning: --threshold {threshold} is the single-band HF/broadband default; \
                     with --bands {bands} it is dB above each band's running average (try 6)"
                );
            }
            let cleaned = audio.map_channels(|c| {
                if bands > 1 {
                    cathar::deess_multiband(c, audio.sample_rate, freq, threshold, 4.0, bands)
                } else {
                    cathar::deesser(c, audio.sample_rate, freq, threshold, 3.0)
                }
            });
            cleaned.to_file(&out)?;
            let mode =
                if bands > 1 { format!("{bands}-band adaptive") } else { "single-band".into() };
            eprintln!(
                "de-essed  crossover={freq} Hz  threshold={threshold} dB  ({mode})  →  {out}"
            );
        }
        Command::Dewind { input, out, cutoff } => {
            let audio = cathar::AudioData::from_file(&input)?;
            let cleaned = audio.map_channels(|c| cathar::dewind(c, audio.sample_rate, cutoff));
            cleaned.to_file(&out)?;
            eprintln!("de-winded  high-pass {cutoff} Hz  →  {out}");
        }
        Command::Deplosive { input, out, strength, method } => {
            let audio = cathar::AudioData::from_file(&input)?;
            let method: cathar::DeplosiveMethod = method.into();
            let cleaned = audio.map_channels(|c| {
                cathar::deplosive_with_method(c, audio.sample_rate, strength, method)
            });
            cleaned.to_file(&out)?;
            let m = match method {
                cathar::DeplosiveMethod::Events => "events",
                cathar::DeplosiveMethod::Transients => "transients",
            };
            eprintln!("de-plosived  strength={strength}  method={m}  →  {out}");
        }
        Command::Derustle { input, out, strength } => {
            let audio = cathar::AudioData::from_file(&input)?;
            let cleaned = audio.map_channels(|c| cathar::derustle(c, audio.sample_rate, strength));
            cleaned.to_file(&out)?;
            eprintln!("de-rustled  strength={strength}  →  {out}");
        }
        Command::Breath { input, out } => {
            let audio = cathar::AudioData::from_file(&input)?;
            let cleaned = audio.map_channels(|c| cathar::breath_remove(c, audio.sample_rate));
            cleaned.to_file(&out)?;
            eprintln!("breath-removed  →  {out}");
        }
        Command::Hpss { input, harmonic, percussive, kernel } => {
            let audio = cathar::AudioData::from_file(&input)?;
            let sr = audio.sample_rate;
            let (mut hs, mut ps) = (Vec::new(), Vec::new());
            for c in &audio.channels {
                let (h, p) = cathar::hpss(c, sr, kernel);
                hs.push(h);
                ps.push(p);
            }
            cathar::AudioData { sample_rate: sr, channels: hs }.to_file(&harmonic)?;
            cathar::AudioData { sample_rate: sr, channels: ps }.to_file(&percussive)?;
            eprintln!("HPSS (kernel {kernel})  →  {harmonic}  +  {percussive}");
        }
        Command::Dewow { input, out } => {
            let audio = cathar::AudioData::from_file(&input)?;
            let sr = audio.sample_rate;
            let cleaned = audio.map_channels(|c| cathar::dewow(c, sr));
            cleaned.to_file(&out)?;
            eprintln!("wow/flutter corrected  →  {out}");
        }
        Command::Sms { input, out } => {
            let audio = cathar::AudioData::from_file(&input)?;
            let sr = audio.sample_rate;
            let cleaned =
                audio.map_channels(|c| cathar::synthesize_sms(&cathar::analyze_sms(c, sr)));
            cleaned.to_file(&out)?;
            eprintln!("SMS tonal purify  →  {out}");
        }
        Command::Azimuth { input, out, max_ms, method } => {
            let audio = cathar::AudioData::from_file(&input)?;
            let sr = audio.sample_rate;
            let method = cathar::LagMethod::from(method);
            let channels = if audio.channels.len() >= 2 {
                let (l, r) = cathar::azimuth_correct_with_method(
                    &audio.channels[0],
                    &audio.channels[1],
                    sr,
                    max_ms,
                    method,
                );
                let lag = cathar::estimate_lag_with_method(
                    &audio.channels[0],
                    &audio.channels[1],
                    sr,
                    max_ms,
                    method,
                );
                eprintln!("azimuth lag  {lag:.2} samples  ({:.3} ms)", lag * 1000.0 / sr as f32);
                vec![l, r]
            } else {
                audio.channels.clone()
            };
            cathar::AudioData { sample_rate: sr, channels }.to_file(&out)?;
            eprintln!("azimuth-corrected  →  {out}");
        }
        Command::Align { input, reference, out, max_ms, method } => {
            let audio = cathar::AudioData::from_file(&input)?;
            let refr = cathar::AudioData::from_file(&reference)?;
            let sr = audio.sample_rate;
            let method = cathar::LagMethod::from(method);
            let mono = |a: &cathar::AudioData| -> Vec<f32> {
                let nch = a.channels.len().max(1);
                let n = a.channels.iter().map(Vec::len).max().unwrap_or(0);
                let mut m = vec![0.0f32; n];
                for ch in &a.channels {
                    for (i, &s) in ch.iter().enumerate() {
                        m[i] += s / nch as f32;
                    }
                }
                m
            };
            let ref_mono = mono(&refr);
            let sig_mono = mono(&audio);
            let lag = cathar::estimate_lag_with_method(&ref_mono, &sig_mono, sr, max_ms, method);
            eprintln!("align lag  {lag:.2} samples  ({:.3} ms)", lag * 1000.0 / sr as f32);
            let channels: Vec<Vec<f32>> = audio
                .channels
                .iter()
                .map(|c| cathar::align_with_method(&ref_mono, c, sr, max_ms, method))
                .collect();
            cathar::AudioData { sample_rate: sr, channels }.to_file(&out)?;
            eprintln!("aligned to {reference}  →  {out}");
        }
        Command::Stereo { input, out, width, mono_below, ms, from_ms, upmix, haas_ms } => {
            let audio = cathar::AudioData::from_file(&input)?;
            let sr = audio.sample_rate;
            let ops =
                [width.is_some(), mono_below.is_some(), ms, from_ms, upmix, haas_ms.is_some()]
                    .iter()
                    .filter(|&&b| b)
                    .count();
            if ops == 0 {
                anyhow::bail!(
                    "stereo: specify at least one of --width, --mono-below, --ms, --from-ms, --upmix, --haas-ms"
                );
            }
            if ms && from_ms {
                anyhow::bail!("stereo: --ms and --from-ms are mutually exclusive");
            }
            if upmix && audio.channels.len() != 1 {
                anyhow::bail!("stereo --upmix expects a mono input");
            }
            if (ms || from_ms || width.is_some() || mono_below.is_some() || haas_ms.is_some())
                && audio.channels.len() < 2
                && !upmix
            {
                anyhow::bail!("stereo: need stereo (2ch) input for this mode");
            }

            let (l, r) = if upmix {
                cathar::upmix_mono(&audio.channels[0], sr)
            } else if from_ms {
                cathar::ms_decode(&audio.channels[0], &audio.channels[1])
            } else if ms {
                cathar::ms_encode(&audio.channels[0], &audio.channels[1])
            } else {
                (audio.channels[0].clone(), audio.channels[1].clone())
            };

            let (l, r) =
                if let Some(hz) = mono_below { cathar::mono_below(&l, &r, sr, hz) } else { (l, r) };
            let (l, r) = if let Some(w) = width { cathar::stereo_width(&l, &r, w) } else { (l, r) };
            let (l, r) = if let Some(ms_delay) = haas_ms {
                cathar::haas_delay(&l, &r, sr, ms_delay)
            } else {
                (l, r)
            };

            let corr = cathar::phase_correlation(&l, &r);
            cathar::AudioData { sample_rate: sr, channels: vec![l, r] }.to_file(&out)?;
            eprintln!("stereo  phase-corr={corr:+.3}  →  {out}");
        }
        Command::Inpaint { input, out, start_ms, len_ms, iterations, max_gap_ms } => {
            let audio = cathar::AudioData::from_file(&input)?;
            let sr = audio.sample_rate;
            let channels: Vec<Vec<f32>> = match (start_ms, len_ms) {
                (Some(s), Some(l)) => {
                    let start = ((s / 1000.0) * sr as f32) as usize;
                    let len = ((l / 1000.0) * sr as f32) as usize;
                    audio
                        .channels
                        .iter()
                        .map(|c| cathar::inpaint_gap(c, start, len, iterations))
                        .collect()
                }
                _ => {
                    audio.channels.iter().map(|c| cathar::inpaint_auto(c, sr, max_gap_ms)).collect()
                }
            };
            cathar::AudioData { sample_rate: sr, channels }.to_file(&out)?;
            eprintln!("inpainted  →  {out}");
        }
        Command::Riaa { input, out, elliptical } => {
            let audio = cathar::AudioData::from_file(&input)?;
            let channels = if audio.channels.len() >= 2 {
                let (l, r) = cathar::vinyl_restore(
                    &audio.channels[0],
                    &audio.channels[1],
                    audio.sample_rate,
                    elliptical,
                );
                vec![l, r]
            } else {
                vec![cathar::riaa_deemphasis(&audio.channels[0], audio.sample_rate)]
            };
            cathar::AudioData { sample_rate: audio.sample_rate, channels }.to_file(&out)?;
            let ellip = elliptical.map(|f| format!("  elliptical {f} Hz")).unwrap_or_default();
            eprintln!("RIAA de-emphasis{ellip}  →  {out}");
        }
        Command::Deemphasis { input, out, curve } => {
            let audio = cathar::AudioData::from_file(&input)?;
            let sr = audio.sample_rate;
            let c: cathar::Emphasis = curve.into();
            let cleaned = audio.map_channels(|ch| cathar::deemphasis(ch, sr, c));
            cleaned.to_file(&out)?;
            eprintln!("de-emphasis ({c:?})  →  {out}");
        }

        Command::Dequantize { input, out, bits, strength, method, iterations } => {
            let audio = cathar::AudioData::from_file(&input)?;
            let cleaned = audio.map_channels(|c| match method {
                DequantMethodArg::Lattice => {
                    cathar::dequantize(c, audio.sample_rate, bits, strength)
                }
                DequantMethodArg::Cosparse => {
                    cathar::dequantize_cosparse(c, audio.sample_rate, bits, strength, iterations)
                }
            });
            cleaned.to_file(&out)?;
            eprintln!("dequantized  {bits}-bit  strength={strength}  method={method:?}  →  {out}");
        }

        Command::Enhance { input, out, rate, method } => {
            let audio = cathar::AudioData::from_file(&input)?;
            let method: cathar::EnhanceMethod = method.into();
            let channels: Vec<Vec<f32>> = audio
                .channels
                .iter()
                .map(|c| cathar::bandwidth_extend_with_method(c, audio.sample_rate, rate, method))
                .collect();
            let result = cathar::AudioData { sample_rate: rate, channels };
            result.to_file(&out)?;
            let mode = match method {
                cathar::EnhanceMethod::Replicate => "replicate",
                cathar::EnhanceMethod::Interpolate => "interpolate",
                cathar::EnhanceMethod::Harmonic => "harmonic",
                cathar::EnhanceMethod::Dsre => "dsre",
            };
            eprintln!("enhanced  {} Hz → {rate} Hz  ({mode})  →  {out}", audio.sample_rate);
        }

        Command::Repair { input, out, strength } => {
            let audio = cathar::AudioData::from_file(&input)?;
            let cleaned = audio.map_channels(|c| cathar::spectral_repair(c, strength));
            cleaned.to_file(&out)?;
            eprintln!("repaired  strength={strength}  →  {out}");
        }

        Command::Resample { input, out, rate } => {
            let audio = cathar::AudioData::from_file(&input)?;
            let from = audio.sample_rate;
            let resampled = audio.resample(rate);
            resampled.to_file(&out)?;
            eprintln!("resampled  {from} Hz → {rate} Hz  →  {out}");
        }

        Command::Tempo { input, out, factor, mode } => {
            let audio = cathar::AudioData::from_file(&input)?;
            let sr = audio.sample_rate;
            let mode: cathar::StretchMode = mode.into();
            let ratio = 1.0 / factor; // factor>1 = faster ⇒ shorter output
            let stretched = audio.map_channels(|c| cathar::time_stretch(c, sr, ratio, mode));
            stretched.to_file(&out)?;
            eprintln!("tempo ×{factor}  →  {out}");
        }

        Command::Pitch { input, out, semitones, mode } => {
            let audio = cathar::AudioData::from_file(&input)?;
            let sr = audio.sample_rate;
            let mode: cathar::StretchMode = mode.into();
            let shifted = audio.map_channels(|c| cathar::pitch_shift(c, sr, semitones, mode));
            shifted.to_file(&out)?;
            eprintln!("pitch {semitones:+} st  →  {out}");
        }

        Command::Speed { input, out, factor } => {
            let audio = cathar::AudioData::from_file(&input)?;
            let sr = audio.sample_rate;
            // Resample by 1/factor and keep the original rate: faster ⇒ higher.
            let from = (sr as f32 * factor).round().max(1.0) as u32;
            let channels: Vec<Vec<f32>> =
                audio.channels.iter().map(|c| cathar::resample(c, from, sr)).collect();
            cathar::AudioData { sample_rate: sr, channels }.to_file(&out)?;
            eprintln!("speed ×{factor}  →  {out}");
        }

        Command::Normalize { input, out, target, peak, true_peak } => {
            let audio = cathar::AudioData::from_file(&input)?;
            if peak {
                let cleaned = audio.map_channels(|c| cathar::normalize_peak(c, target));
                cleaned.to_file(&out)?;
                eprintln!("normalized  {target} dBFS peak  →  {out}");
            } else {
                let before = cathar::integrated_loudness(&audio.channels, audio.sample_rate);
                let cleaned = audio.normalize_r128(target, true_peak);
                let after = cathar::integrated_loudness(&cleaned.channels, cleaned.sample_rate);
                let tp = cathar::true_peak_dbtp(&cleaned.channels, cleaned.sample_rate);
                cleaned.to_file(&out)?;
                eprintln!(
                    "normalized  {before:.1} → {after:.1} LUFS  (target {target}, true peak {tp:.1} dBTP ≤ {true_peak})  →  {out}"
                );
            }
        }

        Command::Vhs { input, out, alpha, beta, cutoff, deess_threshold, normalize } => {
            let audio = cathar::AudioData::from_file(&input)?;
            let opts = cathar::VhsOptions {
                alpha,
                beta,
                dewind_cutoff: cutoff,
                harmonics: 8,
                deess_threshold,
                normalize_lufs: normalize,
            };
            let cleaned = cathar::vhs_restore(&audio, &opts)?;
            cleaned.to_file(&out)?;
            eprintln!(
                "vhs  alpha={alpha}  cutoff={cutoff} Hz  deess={deess_threshold} dB{}  →  {out}",
                normalize.map(|n| format!("  loudness={n} LUFS")).unwrap_or_default()
            );
        }

        Command::Wave { out, sample_rate, freq, duration, noise } => {
            let audio = cathar::generate_wave(sample_rate, freq, duration, noise);
            audio.to_file(&out)?;
            eprintln!(
                "{}  {} Hz  {:.1}s  f={freq} Hz  noise={noise:.2}",
                out, sample_rate, duration
            );
        }

        Command::Batch { indir, outdir, alpha, beta, dehum, normalize, preset, exts } => {
            std::fs::create_dir_all(&outdir)?;
            let chain_preset = preset.map(|path| parse_chain_file(&path)).transpose()?;
            let extensions: Vec<&str> = exts.split(',').map(|s| s.trim()).collect();
            let mut files: Vec<_> = std::fs::read_dir(&indir)?
                .filter_map(|e| e.ok())
                .map(|e| e.path())
                .filter(|p| {
                    p.extension()
                        .and_then(|e| e.to_str())
                        .map(|e| extensions.contains(&e.to_lowercase().as_str()))
                        .unwrap_or(false)
                })
                .collect();
            files.sort();

            let total = files.len();
            let done = std::sync::atomic::AtomicUsize::new(0);

            // Files are independent — each reads, processes, and writes its own
            // output — so fan out across the rayon thread pool. Per-file errors
            // are reported and skipped rather than aborting the whole batch.
            files.par_iter().for_each(|path| {
                let name = path.file_stem().unwrap().to_string_lossy();

                let process = || -> Result<()> {
                    let audio = cathar::AudioData::from_file(&path.to_string_lossy())?;
                    let clean = if let Some(ref chain) = chain_preset {
                        apply_chain(audio, chain.clone())?
                    } else {
                        let denoiser =
                            cathar::SpectralDenoiser { alpha, beta, ..Default::default() };
                        let mut clean = denoiser.denoise(&audio)?;
                        if let Some(freq) = dehum {
                            clean = clean
                                .map_channels(|c| cathar::dehum(c, clean.sample_rate, freq, 5));
                        }
                        if let Some(lu) = normalize {
                            clean = clean.normalize_r128(lu, -1.0);
                        }
                        clean
                    };

                    let out_path = std::path::Path::new(&outdir).join(format!("{name}.wav"));
                    clean.to_file(&out_path.to_string_lossy())?;
                    Ok(())
                };

                let i = done.fetch_add(1, std::sync::atomic::Ordering::Relaxed) + 1;
                match process() {
                    Ok(()) => eprintln!("[{i}/{total}] {name}"),
                    Err(e) => eprintln!("[{i}/{total}] {name}  skip: {e}"),
                }
            });
            eprintln!("done  {total} files  →  {outdir}/");
        }
        #[cfg(feature = "tui")]
        Command::View { input, fft, hop } => {
            tui::run(&input, fft, hop)?;
        }
        Command::Trim { input, out, start, duration } => {
            let audio = cathar::AudioData::from_file(&input)?;
            let trimmed = audio.trim(start, duration);
            trimmed.to_file(&out)?;
            eprintln!("trimmed  {start}s +{duration}s  →  {out}");
        }
        Command::Pad { input, out, pre, post } => {
            let audio = cathar::AudioData::from_file(&input)?;
            audio.pad_extend(pre, post).to_file(&out)?;
            eprintln!("padded  +{pre}s / +{post}s  →  {out}");
        }
        Command::Fade { input, out, fade_in, fade_out } => {
            let audio = cathar::AudioData::from_file(&input)?;
            audio.fade(fade_in, fade_out).to_file(&out)?;
            eprintln!("faded  in={fade_in}s out={fade_out}s  →  {out}");
        }
        Command::Silence { input, out, threshold, min_duration } => {
            let audio = cathar::AudioData::from_file(&input)?;
            audio.silence_strip(threshold, min_duration).to_file(&out)?;
            eprintln!("silence-stripped  threshold={threshold} min={min_duration}s  →  {out}");
        }
        Command::Gain { input, out, db } => {
            let audio = cathar::AudioData::from_file(&input)?;
            audio.gain_db(db).to_file(&out)?;
            eprintln!("gain  {db} dB  →  {out}");
        }
        Command::Remix { input, out, layout } => {
            let audio = cathar::AudioData::from_file(&input)?;
            let spec: Vec<Vec<(usize, f32)>> = match layout.as_str() {
                "mono" => {
                    let n = audio.channels.len();
                    vec![(0..n).map(|i| (i, 1.0 / n as f32)).collect()]
                }
                "swap" if audio.channels.len() >= 2 => {
                    vec![vec![(1, 1.0)], vec![(0, 1.0)]]
                }
                "swap" => {
                    anyhow::bail!("swap needs at least 2 channels");
                }
                other => {
                    anyhow::bail!("unknown layout: {other}. Use 'mono' or 'swap'")
                }
            };
            audio.remix(&spec).to_file(&out)?;
            eprintln!("remixed  {layout}  →  {out}");
        }
        Command::Channels { input, out, indices } => {
            let audio = cathar::AudioData::from_file(&input)?;
            let ids: Vec<usize> =
                indices.split(',').filter_map(|s| s.trim().parse().ok()).collect();
            if ids.is_empty() {
                anyhow::bail!("no valid channel indices in: {indices}");
            }
            let out_audio = cathar::AudioData {
                sample_rate: audio.sample_rate,
                channels: cathar::select_channels(&audio.channels, &ids),
            };
            out_audio.to_file(&out)?;
            eprintln!("channels  {:?}  →  {out}", ids);
        }
        Command::Reverse { input, out } => {
            let audio = cathar::AudioData::from_file(&input)?;
            audio.reverse().to_file(&out)?;
            eprintln!("reversed  →  {out}");
        }
        Command::Lowpass { input, out, freq } => {
            let audio = cathar::AudioData::from_file(&input)?;
            audio.map_channels(|c| cathar::lowpass(c, audio.sample_rate, freq)).to_file(&out)?;
            eprintln!("lowpass  {freq} Hz  →  {out}");
        }
        Command::Highpass { input, out, freq } => {
            let audio = cathar::AudioData::from_file(&input)?;
            audio.map_channels(|c| cathar::highpass(c, audio.sample_rate, freq)).to_file(&out)?;
            eprintln!("highpass  {freq} Hz  →  {out}");
        }
        Command::Bandpass { input, out, freq, q } => {
            let audio = cathar::AudioData::from_file(&input)?;
            audio
                .map_channels(|c| cathar::bandpass(c, audio.sample_rate, freq, q))
                .to_file(&out)?;
            eprintln!("bandpass  {freq} Hz  Q={q}  →  {out}");
        }
        Command::Equalizer { input, out, freq, q, gain } => {
            let audio = cathar::AudioData::from_file(&input)?;
            audio
                .map_channels(|c| cathar::equalizer(c, audio.sample_rate, freq, q, gain))
                .to_file(&out)?;
            eprintln!("eq  {freq} Hz  Q={q}  {gain} dB  →  {out}");
        }
        Command::Bass { input, out, freq, gain } => {
            let audio = cathar::AudioData::from_file(&input)?;
            audio.map_channels(|c| cathar::bass(c, audio.sample_rate, freq, gain)).to_file(&out)?;
            eprintln!("bass  {freq} Hz  {gain} dB  →  {out}");
        }
        Command::Treble { input, out, freq, gain } => {
            let audio = cathar::AudioData::from_file(&input)?;
            audio
                .map_channels(|c| cathar::treble(c, audio.sample_rate, freq, gain))
                .to_file(&out)?;
            eprintln!("treble  {freq} Hz  {gain} dB  →  {out}");
        }
        Command::Compress { input, out, threshold, ratio, attack, release } => {
            let audio = cathar::AudioData::from_file(&input)?;
            audio
                .map_channels(|c| {
                    cathar::compressor(c, audio.sample_rate, threshold, ratio, attack, release)
                })
                .to_file(&out)?;
            eprintln!("compressed  {threshold} dB  {ratio}:1  →  {out}");
        }
        Command::Limit { input, out, ceiling } => {
            let audio = cathar::AudioData::from_file(&input)?;
            audio.map_channels(|c| cathar::limiter(c, audio.sample_rate, ceiling)).to_file(&out)?;
            eprintln!("limited  ceiling={ceiling} dBFS  →  {out}");
        }
        Command::Gate { input, out, threshold, attack, release } => {
            let audio = cathar::AudioData::from_file(&input)?;
            audio
                .map_channels(|c| cathar::gate(c, audio.sample_rate, threshold, attack, release))
                .to_file(&out)?;
            eprintln!("gated  {threshold} dBFS  →  {out}");
        }
        Command::Echo { input, out, delay_ms, feedback, mix } => {
            let audio = cathar::AudioData::from_file(&input)?;
            audio
                .map_channels(|c| cathar::echo(c, audio.sample_rate, delay_ms, feedback, mix))
                .to_file(&out)?;
            eprintln!("echo  delay={delay_ms} ms  →  {out}");
        }
        Command::Reverb { input, out, room, mix } => {
            let audio = cathar::AudioData::from_file(&input)?;
            audio
                .map_channels(|c| cathar::reverb(c, audio.sample_rate, room, mix))
                .to_file(&out)?;
            eprintln!("reverb  room={room}  →  {out}");
        }
        Command::Chorus { input, out, rate, depth_ms, mix } => {
            let audio = cathar::AudioData::from_file(&input)?;
            audio
                .map_channels(|c| cathar::chorus(c, audio.sample_rate, rate, depth_ms, mix))
                .to_file(&out)?;
            eprintln!("chorus  rate={rate} Hz  →  {out}");
        }
        Command::Flanger { input, out, rate, depth_ms, feedback, mix } => {
            let audio = cathar::AudioData::from_file(&input)?;
            audio
                .map_channels(|c| {
                    cathar::flanger(c, audio.sample_rate, rate, depth_ms, feedback, mix)
                })
                .to_file(&out)?;
            eprintln!("flanger  rate={rate} Hz  →  {out}");
        }
        Command::Phaser { input, out, rate, depth, feedback, mix } => {
            let audio = cathar::AudioData::from_file(&input)?;
            audio
                .map_channels(|c| cathar::phaser(c, audio.sample_rate, rate, depth, feedback, mix))
                .to_file(&out)?;
            eprintln!("phaser  rate={rate} Hz  →  {out}");
        }
        Command::Tremolo { input, out, rate, depth } => {
            let audio = cathar::AudioData::from_file(&input)?;
            audio
                .map_channels(|c| cathar::tremolo(c, audio.sample_rate, rate, depth))
                .to_file(&out)?;
            eprintln!("tremolo  rate={rate} Hz  →  {out}");
        }
        Command::Overdrive { input, out, drive, mix } => {
            let audio = cathar::AudioData::from_file(&input)?;
            audio.map_channels(|c| cathar::overdrive(c, drive, mix)).to_file(&out)?;
            eprintln!("overdrive  drive={drive}  →  {out}");
        }
        Command::Compand { input, out, threshold, ratio, attack, release, makeup } => {
            let audio = cathar::AudioData::from_file(&input)?;
            audio
                .map_channels(|c| {
                    cathar::compand_dynamic(
                        c,
                        audio.sample_rate,
                        threshold,
                        ratio,
                        attack,
                        release,
                        makeup,
                    )
                })
                .to_file(&out)?;
            eprintln!(
                "compand  threshold={threshold} dB  ratio={ratio}:1  attack={attack}s  release={release}s  →  {out}"
            );
        }
        Command::Contrast { input, out, amount } => {
            let audio = cathar::AudioData::from_file(&input)?;
            audio.map_channels(|c| cathar::contrast(c, amount)).to_file(&out)?;
            eprintln!("contrast  amount={amount}  →  {out}");
        }
        Command::PsychoDenoise { input, out, alpha, beta } => {
            let audio = cathar::AudioData::from_file(&input)?;
            let cleaned =
                audio.map_channels(|c| cathar::psycho_denoise(c, audio.sample_rate, alpha, beta));
            cleaned.to_file(&out)?;
            eprintln!("psycho-denoise  alpha={alpha}  beta={beta}  →  {out}");
        }
        Command::Rebalance { input, reference, out, strength } => {
            let audio = cathar::AudioData::from_file(&input)?;
            let ref_audio = cathar::AudioData::from_file(&reference)?;
            if audio.sample_rate != ref_audio.sample_rate {
                anyhow::bail!(
                    "sample-rate mismatch: input {} Hz, reference {} Hz",
                    audio.sample_rate,
                    ref_audio.sample_rate
                );
            }
            let ref_channel = ref_audio
                .channels
                .first()
                .ok_or_else(|| anyhow::anyhow!("reference has no audio channel"))?;
            audio
                .map_channels(|c| {
                    cathar::spectral_rebalance(c, ref_channel, audio.sample_rate, strength)
                })
                .to_file(&out)?;
            eprintln!("rebalanced  reference={reference}  strength={strength}  →  {out}");
        }
        Command::Deconvolve { input, impulse, out, regularization } => {
            let audio = cathar::AudioData::from_file(&input)?;
            let ir = cathar::AudioData::from_file(&impulse)?;
            if audio.sample_rate != ir.sample_rate {
                anyhow::bail!(
                    "sample-rate mismatch: input {} Hz, impulse response {} Hz",
                    audio.sample_rate,
                    ir.sample_rate
                );
            }
            let ir_channel = ir
                .channels
                .first()
                .ok_or_else(|| anyhow::anyhow!("impulse response has no audio channel"))?;
            let cleaned = audio.map_channels(|c| cathar::deconvolve(c, ir_channel, regularization));
            cleaned.to_file(&out)?;
            eprintln!("deconvolved  IR={impulse}  regularization={regularization}  →  {out}");
        }
        Command::Chain { input, preset, out } => {
            let audio = cathar::AudioData::from_file(&input)?;
            let chain = parse_chain_file(&preset)?;
            let stages = chain.stages.len();
            apply_chain(audio, chain)?.to_file(&out)?;
            eprintln!("chain  {stages} stage(s) from {preset}  →  {out}");
        }
        Command::Dither { input, out, bits } => {
            let audio = cathar::AudioData::from_file(&input)?;
            audio.dither(bits).to_file(&out)?;
            eprintln!("dithered  {bits}-bit TPDF  →  {out}");
        }
        Command::Stats { input } => {
            let audio = cathar::AudioData::from_file(&input)?;
            if let Some(stats) = cathar::compute_stats(&audio.channels, audio.sample_rate) {
                println!("{input}");
                println!("  Sample rate  {:>8} Hz", stats.sample_rate);
                println!("  Channels     {:>8}", stats.channels);
                println!("  Duration     {:>8.2} s", stats.duration_sec);
                println!("  Samples      {:>8}", stats.samples);
                println!("  ────────────────────────");
                println!("  Peak         {:>8.1} dBFS", stats.peak_dbfs);
                println!("  RMS          {:>8.1} dBFS", stats.rms_dbfs);
                println!("  Crest factor {:>8.1} dB", stats.crest_factor_db);
                println!("  Integrated   {:>8.1} LUFS", stats.integrated_lufs);
                println!("  True peak    {:>8.1} dBTP", stats.true_peak_dbtp);
                println!("  DC offset    {:>8.4}", stats.dc_offset);
                println!("  Noise floor  {:>8.1} dBFS", stats.noise_floor_dbfs);
                println!("  SNR          {:>8.1} dB", stats.snr_db);
                println!(
                    "  Clipped      {:>8} smp / {} run(s)",
                    stats.clipped_samples, stats.clipped_runs
                );
                // Monophonic pitch estimate over a mono mixdown.
                let n = audio.channels.iter().map(Vec::len).max().unwrap_or(0);
                let nch = audio.channels.len().max(1);
                let mut mono = vec![0.0f32; n];
                for ch in &audio.channels {
                    for (i, &s) in ch.iter().enumerate() {
                        mono[i] += s / nch as f32;
                    }
                }
                match cathar::fundamental_hz(&mono, audio.sample_rate) {
                    Some(f0) => println!("  Pitch (f0)   {f0:>8.1} Hz"),
                    None => println!("  Pitch (f0)        —    (unvoiced)"),
                }
                if stats.channels > 1 {
                    print!("  Ch peaks     ");
                    for (i, &p) in stats.channel_peaks.iter().enumerate() {
                        print!("ch{i}={p:.1}  ");
                    }
                    println!();
                    if let Some(pc) = stats.phase_correlation {
                        println!("  Phase corr   {pc:>+8.3}  (−1 out-of-phase … +1 mono)");
                    }
                }
                let hints = stats.suggestions();
                if !hints.is_empty() {
                    println!("  ────────────────────────");
                    for h in hints {
                        println!("  → {:<10} {}", h.issue, h.invocation(&input));
                        println!("               {}", h.detail);
                    }
                }
            } else {
                eprintln!("{input}: empty or unreadable");
            }
        }
        Command::Convert { input, out } => {
            let audio = cathar::AudioData::from_file(&input)?;
            eprintln!(
                "{}  {} Hz  {} ch  {:.1}s  →  {}",
                input,
                audio.sample_rate,
                audio.channels.len(),
                audio.channels[0].len() as f32 / audio.sample_rate as f32,
                out
            );
            audio.to_file(&out)?;
            eprintln!("wrote  {out}");
        }
        #[cfg(feature = "ml")]
        Command::MlDenoise { input, out, weights, passthrough } => {
            let audio = cathar::AudioData::from_file(&input)?;
            let orig_power = power(&audio.channels[0]);
            let denoiser = match (weights.as_deref(), passthrough) {
                (Some(path), _) => {
                    eprintln!("ml denoise  weights={path}");
                    cathar::NeuralDenoiser::from_safetensors(path, cathar::NeuralConfig::default())?
                }
                (_, true) => {
                    eprintln!("ml denoise  passthrough model (near no-op)");
                    cathar::NeuralDenoiser::new()?
                }
                (None, false) => {
                    eprintln!(
                        "ml denoise  pretrained model (synthetic tones — retrain on DNS-Challenge for speech)"
                    );
                    cathar::NeuralDenoiser::pretrained()?
                }
            };
            let clean = denoiser.denoise(&audio)?;
            clean.to_file(&out)?;
            if let (Some(o), Some(c)) = (orig_power, power(&clean.channels[0])) {
                if o > 0.0 {
                    eprintln!("reduction  {:.1}%", (1.0 - c / o) * 100.0);
                }
            }
            eprintln!("wrote  {out}");
        }
        #[cfg(feature = "tui")]
        Command::Play { input, fft } => {
            player::run(&input, fft)?;
        }
    }

    Ok(())
}

fn mixdown(audio: &cathar::AudioData) -> Vec<f32> {
    let n_ch = audio.channels.len();
    if n_ch <= 1 {
        return audio.channels.first().cloned().unwrap_or_default();
    }
    let len = audio.channels.iter().map(|c| c.len()).min().unwrap_or(0);
    (0..len).map(|i| audio.channels.iter().map(|c| c[i]).sum::<f32>() / n_ch as f32).collect()
}

fn power(channel: &[f32]) -> Option<f32> {
    if channel.is_empty() {
        return None;
    }
    let mean = channel.iter().sum::<f32>() / channel.len() as f32;
    Some(channel.iter().map(|x| (x - mean).powi(2)).sum::<f32>() / channel.len() as f32)
}
